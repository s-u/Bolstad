print.sintegral = function(x, ...){
  cat(paste0("Value: ", x$value, "\n", ...))
}